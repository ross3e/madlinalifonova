import axios from "axios";

export const a = axios.create({
  baseURL: "https://5d6ac01ed89c41ed.mokky.dev",
});

a.get('/products') // ← замени на своё имя коллекции
  .then(res => console.log(res.data))
  .catch(err => {
    console.error('Ошибка:', err.message);
    console.error('Код:', err.response?.status);
    console.error('URL:', err.config?.url);
  });