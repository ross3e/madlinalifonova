import LoadingGif from "../../assets/images/loading.gif";

function Loading() {
    return (
        <div className="loading">
            <img src={LoadingGif} alt="Loading" />
        </div>
    );
}

export default Loading; 