export const DASHBOARD = "/";

export const CATEGORIES = "/categories";
export const CREATE_CATEGORY = "/category/Createcategory";
export const UPDATE_CATEGORY = "/category/Updatecategory/:id";
export const DELETE_CATEGORY = "/category/Deletecategory/:id";
