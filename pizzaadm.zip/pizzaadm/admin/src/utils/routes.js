import Category from "../pages/category/Category";
import Createcategory from "../pages/category/Createcategory";
import Deletecategory from "../pages/category/Deletecategory";
import Updatecategory from "../pages/category/Updatecategory";
import Dashboard from "../pages/dashboard";

import {
    DASHBOARD,
    CATEGORIES,
    DELETE_CATEGORY,
    UPDATE_CATEGORY,
    CREATE_CATEGORY
} from "./consts";

export const routes = [
    {
        path: DASHBOARD,
        element: Dashboard
    },
    {
        path: CATEGORIES,
        element: Category
    },
    {
        path: DELETE_CATEGORY,
        element: Deletecategory
    },
    {
        path: UPDATE_CATEGORY,
        element: Updatecategory
    },
    {
        path: CREATE_CATEGORY,
        element: Createcategory
    },
];