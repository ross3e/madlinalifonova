import Categorylist from "../../components/Categories/CategoryList";

function Category() {
    return (
        <section className="block">
            <div className="container">
                <div className="block-header">
                    <h1 className="title">Категории</h1>
                    <span className="btn bg-primary">Создать</span>
                </div>
                <Categorylist />
            </div>
        </section>
    );
}

export default Category;