import axios from "axios";

export const a = axios.create({
    baseURL: "https://5d6ac01ed89c41ed.mokky.dev"
});