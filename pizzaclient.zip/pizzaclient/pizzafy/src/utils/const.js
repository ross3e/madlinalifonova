export const HOME = "/";
export const CARD = "/card";
export const CHECKOUT = "/checkout";