import { useEffect, useState } from "react";
import Productitem from "./prodeuctitem"; 
import { a } from "../../services/axiosinctanc"; 

function Productlist() {
    const [products, setProducts] = useState([]); // 

    useEffect(() => {
        async function fetchProducts() { 
            try {
                const res = await a.get('/products');
                setProducts(res.data);
            } catch (error) {
                console.error("error:", error);
            }
        }

        fetchProducts(); 
    }, []);

    return (
        <div className="products-list"> 
            {products.map((product) => (
                <Productitem key={product.id} product={product} />
            ))}
        </div>
    );
}

export default Productlist;