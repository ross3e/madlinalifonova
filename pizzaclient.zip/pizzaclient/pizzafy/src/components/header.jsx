import logo from "../assets/images/logo.svg";
import { Link } from 'react-router-dom'; 
import { CARD } from "../utils/const";
import { useCart } from "../context/Cartcontext";

function Header() {


    const {totalQuantity} = useCart();
    return (
        <header className="header"> 
            <div className="container header-flex"> 
                <Link to={CARD} className="cart-button">Корзина : {totalQuantity}</Link> 
            </div>
        </header>
    );
}

export default Header;