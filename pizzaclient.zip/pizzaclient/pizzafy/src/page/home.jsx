import slide1 from "../assets/images/home/1.jpg";
import slide2 from "../assets/images/home/2.jpg";
import slide3 from "../assets/images/home/3.jpg";
import slide4 from "../assets/images/home/4.jpg";
import slide5 from "../assets/images/home/5.jpg";
import Productlist from "../components/products/productslist";

function Home(){
    return(
        <>
            <section className="block">
                <div className="container">
                    <h1 className="title">Ухо5д1 1 н3 смотр1 |||made lina lifonova</h1>
                    <div className="stories-list">
                        <img src={slide1} alt="1" />
                        <img src={slide2} alt="1" />
                        <img src={slide3} alt="1" />
                        <img src={slide4} alt="1" />
                        <img src={slide5} alt="1" />
                    </div>
                </div>
            </section>
            <section className="block">
                <div className="container">
                    <h1 className="title">Меню</h1>
                    <Productlist />
                </div>
            </section>
        </>
    );
}

export default Home;