import { useState } from "react";
import { useCart } from "../context/Cartcontext";
import { CARD, HOME } from "../utils/const";
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

function Checkout() {
    const { clearCart, totalPrice, cartItems } = useCart();
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        address: '',
        city: 'Алматы',
    });

    const [isSubmitting, setIsSubmitting] = useState(false);

    function handleInputChange(event) {
        const { name, value } = event.target;
        setFormData(prevData => ({
            ...prevData,
            [name]: value,
        }));
    }

    async function handleSubmit(event) {
        event.preventDefault();

        if (!formData.name || !formData.phone || !formData.address || !formData.city) {
            alert("заполни пустоту");
            return;
        }

        if (!Array.isArray(cartItems) || cartItems.length === 0) {
            alert("нищий...");
            navigate(HOME);
            return;
        }

        setIsSubmitting(true);

        const orderTimestamp = new Date().toISOString();
        const orderData = {
            customer: formData,
            items: cartItems,
            totalPrice,
            orderTimestamp,
        };

        try {
            const res = await axios.post(
                'https://5d6ac01ed89c41ed.mokky.dev/orders',
                orderData
            );
            alert(`сКоро все буд4т\nСумма: ${totalPrice.toLocaleString()}₸\nНомер нычк1: ${res.data.id}`);
            clearCart();
            navigate(HOME);
        } catch (error) {
            console.error("error:", error);
            alert("1д1 nаx");
        } finally {
            setIsSubmitting(false);
        }
    }

    return (
        <section className="block">
            <div className="container">
                <Link to={CARD} className="back-btn">Назад</Link>
                <h1 className="title">Оформление заказа</h1>
                <form className="form" onSubmit={handleSubmit}>
                    <div className="form-control">
                        <label htmlFor="name" className="label">Ваше имя</label>
                        <input
                            value={formData.name}
                            onChange={handleInputChange}
                            disabled={isSubmitting}
                            type="text"
                            name="name"
                            placeholder="Введите имя"
                            required
                        />
                    </div>
                    <div className="form-control">
                        <label htmlFor="phone" className="label">Номер телефона</label>
                        <input
                            value={formData.phone}
                            onChange={handleInputChange}
                            disabled={isSubmitting}
                            type="text"
                            name="phone"
                            placeholder="Введите номер телефона: +7 XXX XXX XX XX"
                            required
                        />
                    </div>
                    <div className="form-control">
                        <label htmlFor="address" className="label">Адрес</label>
                        <textarea
                            name="address"
                            value={formData.address}
                            onChange={handleInputChange}
                            disabled={isSubmitting}
                            placeholder="Введите адрес, дом, квартиру, домофон"
                            required
                        />
                    </div>
                    <div className="form-control">
                        <label htmlFor="city" className="label">Город</label>
                        <select
                            name="city"
                            value={formData.city}
                            onChange={handleInputChange}
                            disabled={isSubmitting}
                        >
                            <option value="Алматы">Алматы</option>
                            <option value="Астана">Астана</option>
                            <option value="MEF">MEF</option>
                        </select>
                    </div>
                    <button className="send-btn" disabled={isSubmitting}>
                        {isSubmitting ? 'Жди...' : 'Хочу'}
                    </button>
                </form>
            </div>
        </section>
    );
}

export default Checkout;