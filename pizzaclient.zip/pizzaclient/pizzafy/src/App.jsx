import "./assets/css/style.css";
import Header from "./components/header";
import { Routes, Route } from "react-router-dom";
import Home from "./page/home";
import Card from "./page/card";
import Checkout from "./page/checkout";
import { HOME, CARD, CHECKOUT } from "./utils/const"; 

function App() {
  return (
    <>
      <Header />
      <main>
        <Routes>
          <Route path={HOME} element={<Home />} />
          <Route path={CARD} element={<Card />} />
          <Route path={CHECKOUT} element={<Checkout />} />
        </Routes>
      </main>
    </>
  );
}

export default App;